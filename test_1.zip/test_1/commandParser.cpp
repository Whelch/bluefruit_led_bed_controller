#include "state.h"
#include "string.h"
#include "mathLib.h"

void processBrightnessCommand(State *state) {
  boolean failed = true;
  boolean fluxSet = false; // Used for argument ordering.
  while (String token = strtok(NULL, " -\n")) {
    if (token.equals("h") || token.equals("help")) {
      if (token = strtok(NULL, " -\n")) {
        failed = false;
        state->ble.println(F("--==[help]==--"));
        state->ble.print(F("--==[")); state->ble.print(token); state->ble.println(F("]==--"));
        if (token.equals("h") || token.equals("help")) {
          state->ble.println(F("- Literally no."));
        } else if(token.toInt()) {
          state->ble.println(F("- This argument is REQUIRED, UNLESS you are specifying a flux."));
          state->ble.println(F("- This argument must be an integer between 0 and 255, inclusive."));
        } else if (token.equals("f") || token.equals("flux") || token.equals("fluxuation")) {
          state->ble.println(F("- This argument is optional."));
          state->ble.println(F("- This argument has 2 REQUIRED parameters, which MUST appear in the following order:"));
          state->ble.println(F("- The first parameter must be an integer between 0 and 255, inclusive."));
          state->ble.println(F(" + This parameter will be the target brightness to oscilate between."));
          state->ble.println(F("- The second parameter must be an integer between 0 and 65535, inclusive."));
          state->ble.println(F(" + This parameter is the period of the oscilation, in milliseconds."));
        } else {
          state->ble.print(F("This isn't really a token, so you prolly shouldn't use it : P"));
        }
      }
      break;
    } else if (token.equals("f") || token.equals("flux") || token.equals("fluxuation")) {
      uint8_t targetBrightness;
      if (token = strtok(NULL, " -\n")) {
        if (uint16_t otherBrightness = token.toInt()) {
          if (otherBrightness > UINT8_MAX) {
            state->ble.println(F("Invalid first parameter to the [fluxuation] argument."));
            state->ble.println(F("Expected a value in the range [0-255]."));
            break;
          } else {
            targetBrightness = otherBrightness;
            if (token = strtok(NULL, " -\n")) {
              if (uint32_t period = token.toInt()) {
                if (period > UINT16_MAX) {
                  state->ble.println(F("Invalid second parameter to the [fluxuation] argument."));
                  state->ble.println(F("Expected a value in the range [0-65535]."));
                  break;
                } else {
                  fluxSet = true;
                  failed = false;
                  state->brightFlux.active = true;
                  state->brightFlux.start = state->brightness;
                  state->brightFlux.end = targetBrightness;
                  state->brightFlux.duration = period*500; // Convert to micros and halve to get the start->end duration.
                  state->brightFlux.currentTime = 0;
                  state->ble.println(F("Brightness fluxuation enabled."));
                }
              }
            }
          }
        }
      }
    } else if(uint16_t newVal = token.toInt()) {
      failed = false;
      if (newVal > UINT8_MAX) {
        state->ble.println(F("The number argument must be in the range [0-255]"));
        state->ble.println(F("Example: \"b 150\""));
      } else {
        for (uint16_t stripIndex = 0; stripIndex < NUM_STRIPS; stripIndex++) {
          state->strips[stripIndex].setBrightness(newVal);
          state->stripDirty[stripIndex] = true;
        }
        if(fluxSet) {
          state->brightFlux.start = newVal;
        } else {
          state->brightFlux.active = false;
        }
        
        Serial.print(F("Adjusting brightness: ")); Serial.println(newVal);
      }
    }  else {
      state->ble.print(F("Unrecognized argument: [")); state->ble.print(token); state->ble.println(F("]"));
    }
  }
  if(failed) {
    if(state->brightFlux.active) {
      state->brightFlux.active = false;
      state->ble.println(F("Brightness fluxuation disabled."));
    } else {
      state->ble.println(F("--==[brightness]==--"));
      state->ble.println(F("Available arguments:"));
      state->ble.println(F("help {argument} <optional>"));
      state->ble.println(F(" + Provides additional information about the next argument."));
      state->ble.println(F(" + Terminates any additional execution."));
      state->ble.println(F("\nfluxuation [0-255] [0-65535] <optional>"));
      state->ble.println(F(" + Oscilates between two brightness levels, over a given period."));
      state->ble.println(F("\n[0-255] <required>"));
      state->ble.println(F(" + The new brightness value."));
      state->ble.println(F("\nExamples:"));
      state->ble.println(F(" b 150"));
      state->ble.println(F(" bright 0"));
      state->ble.println(F(" brightness help fluxuation"));
    }
  }
}

void initializePingPongMode(State *state) {
  uint8_t r = state->color >> 16;
  uint8_t g = state->color >> 8;
  uint8_t b = state->color;
  for (uint16_t index = 0; index < state->pingpong.spread; index++) {
    state->pingpong.colorFalloff[index] = Color(r, g, b);
    r /= 2;
    g /= 2;
    b /= 2;
  }
  
  for (uint16_t stripIndex = 0; stripIndex < NUM_STRIPS; stripIndex++) {
    for (uint16_t ledIndex = 0; ledIndex < state->strips[stripIndex].numPixels(); ledIndex++) {
      if (state->pingpong.dark) {
        state->stripColors[stripIndex][ledIndex] = Color(0, 0, 0);
      } else {
        state->stripColors[stripIndex][ledIndex] = state->pingpong.colorFalloff[state->pingpong.spread-1];
      }
      state->strips[stripIndex].setPixelColor(ledIndex, state->stripColors[stripIndex][ledIndex]);
    }
    state->stripDirty[stripIndex];
  }
}

void processPingPongCommand(State *state) {
  boolean failed = true;
  if (String token = strtok(NULL, " -\n")) {
    uint16_t spread = token.toInt();
    if (spread <= 8) {
      if (token = strtok(NULL, " -\n")) {
        uint32_t duration = token.toInt();
        if (duration <= UINT16_MAX) {

          failed = false;
          state->pingpong.active = true;
          state->pingpong.spread = spread;
          state->pingpong.pixel = spread;
          state->pingpong.duration = duration*1000;
          state->pingpong.directionUp = false;
          state->pingpong.dark = false;
          state->pingpong.colorFalloff = new uint32_t[spread];
          
          if (token = strtok(NULL, " -\n")) {
            if(token.equals("d") || token.equals("dark")) {
              state->pingpong.dark = true;
            }
          }

          initializePingPongMode(state);
          
          state->ble.println(F("PingPong mode enabled."));
        }
      }
    }
  }
  if(failed) {
    if (state->pingpong.active) {
      state->pingpong.active = false;
      state->ble.println(F("PingPong mode disabled."));
    } else {
      state->ble.println(F("--==[pingpong]==--"));
      state->ble.println(F("Takes 2 arguments"));
      state->ble.println(F("- [1-8] pixel spread"));
      state->ble.println(F("- [1-65535] duration of a cyle in ms"));
      state->ble.println(F("- ['dark'] (optional) specifies that all other pixels should be turned off"));
      state->ble.println(F("\nExamples:"));
      state->ble.println(F(" pingpong 5 5000 d"));
    }
  }
}

