#ifndef MATH_LIB_H_
#define MATH_LIB_H_

#define PI 3.14159265

enum Easing: uint8_t {
  linear = 1,
  cosine = 2,
  exponential = 3
};

long lerp(double percent, long start, long end);

uint32_t Color(uint8_t r, uint8_t g, uint8_t b);

double easing_cosine(double input);

double easing_exponential(double input);

double easing_quartic(double input);

double easing_linear(double input);

#endif
